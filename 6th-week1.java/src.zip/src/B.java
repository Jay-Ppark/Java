public class B extends A {

	public void method1() {
		System.out.println("B1");
		super.method1();
	}
}
