public class D extends C {

	public void method2() {
		super.method2();
		System.out.println("D2");
	}
}
